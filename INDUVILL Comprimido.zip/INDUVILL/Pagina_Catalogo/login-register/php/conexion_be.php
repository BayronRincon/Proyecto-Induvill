<?php


$conexion = mysqli_connect("127.0.0.1:3306", "root", "", "login_register");

// if($conexion){
//     echo 'Conectado exitosamente a la Base de Datos';
// }else {
//     echo 'No se ha podido conectar a la Base de Datos';
// }


?>