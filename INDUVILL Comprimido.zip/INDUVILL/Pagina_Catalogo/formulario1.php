<?php

include_once("")

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="post">
        Nombre: <input type="text" name="nombre" required><br>
        descripcion: <input type="text" name="descripcion" required><br>
        Existencial_inicial: <input type="text" name="existencial_inicial" required><br>
        <input type="submit" value="Insertar">
    </form>
</body>
</html>